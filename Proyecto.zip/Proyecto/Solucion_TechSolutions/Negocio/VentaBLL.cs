﻿// CAPA NEGOCIO (BLL) – ventas. Valida las reglas y delega la transacción a la capa de Datos.
using System;
using System.Collections.Generic;
using System.Linq;          // GroupBy, Select, Sum, Any, All
using Datos;
using Entidades;

namespace Negocio
{
    public class VentaBLL
    {
        private readonly VentaDAL dal = new VentaDAL();

        // Sum con lambda: total de la venta
        public decimal CalcularTotal(IEnumerable<LineaVenta> lineas)
        {
            return lineas.Sum(l => l.Subtotal);
        }

        public int Registrar(int idUsuario, int idCliente, IEnumerable<LineaVenta> lineas)
        {
            if (idUsuario <= 0)
                throw new ArgumentException("No hay un usuario con sesión activa.");
            if (idCliente <= 0)
                throw new ArgumentException("Seleccione el cliente.");
            if (lineas == null || !lineas.Any())
                throw new ArgumentException("La venta debe incluir al menos un producto.");
            if (lineas.Any(l => l.Cantidad <= 0))
                throw new ArgumentException("Todas las cantidades deben ser mayores que cero.");

            // GroupBy: si un producto aparece en varias líneas, se suman sus cantidades
            List<LineaVenta> agrupadas = lineas
                .GroupBy(l => l.IdProducto)
                .Select(g => new LineaVenta
                {
                    IdProducto = g.Key,
                    Producto = g.First().Producto,
                    Cantidad = g.Sum(x => x.Cantidad),
                    PrecioUnitario = g.First().PrecioUnitario
                })
                .ToList();

            return dal.Registrar(idUsuario, idCliente, agrupadas);   // transacción: COMMIT o ROLLBACK
        }
    }
}
