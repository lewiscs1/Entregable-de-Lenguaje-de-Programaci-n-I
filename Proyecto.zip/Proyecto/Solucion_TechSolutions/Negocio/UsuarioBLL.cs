﻿// CAPA NEGOCIO (BLL) – reglas de inicio de sesión y de registro de usuarios.
// REGLA: bloqueo automático y permanente tras 3 intentos fallidos consecutivos.
//        Solo el personal de soporte técnico puede desbloquear (UPDATE en la base de datos).
using System;
using System.Collections.Generic;
using Datos;
using Entidades;

namespace Negocio
{
    public class UsuarioBLL
    {
        public const string RolAdministrador = "Administrador";
        public const string RolVendedor = "Vendedor";
        public const string RolAlmacenero = "Almacenero";
        public static readonly string[] Roles = { RolAdministrador, RolVendedor, RolAlmacenero };

        public const int MaxIntentosFallidos = 3;

        private const string MensajeCredenciales = "Usuario o contraseña incorrectos.";
        private const string MensajeBloqueada =
            "La cuenta está bloqueada por 3 intentos fallidos consecutivos. " +
            "Solicite el desbloqueo al personal de soporte técnico.";

        // Sal ficticia: si el usuario no existe se calcula igual un hash, para que la respuesta
        // tarde lo mismo y no se pueda averiguar qué usuarios existen midiendo el tiempo.
        private static readonly string SalFicticia = Seguridad.NuevaSal();

        private readonly UsuarioDAL dal = new UsuarioDAL();

        public Usuario Autenticar(string login, string clave)
        {
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrEmpty(clave) || login.Length > 30)
                throw new UnauthorizedAccessException(MensajeCredenciales);

            Usuario u = dal.BuscarPorLogin(login);            // 1) trae SU sal y SU hash

            if (u == null)
            {
                Seguridad.Hash(clave, SalFicticia);           // mismo costo de cálculo que un usuario real
                throw new UnauthorizedAccessException(MensajeCredenciales);   // mensaje genérico
            }

            if (u.Bloqueado)                                  // cuenta ya bloqueada: no se evalúa la clave
                throw new UnauthorizedAccessException(MensajeBloqueada);

            // 2) calcula el hash de lo escrito con esa sal y lo compara con el guardado
            if (Seguridad.Verificar(clave, u.Sal, u.ClaveHash))
            {
                if (u.IntentosFallidos != 0)
                    dal.ActualizarIntentosYBloqueo(u.Login, 0, false);   // inicio correcto: contador a cero
                return u;
            }

            // 3) clave incorrecta: suma el intento EN LA BASE DE DATOS (una sola sentencia, atómica)
            int intentos;
            bool bloqueada = dal.RegistrarIntentoFallido(u.Login, MaxIntentosFallidos, out intentos);
            if (bloqueada)
                throw new UnauthorizedAccessException(MensajeBloqueada);   // tercer intento fallido consecutivo

            throw new UnauthorizedAccessException(MensajeCredenciales);
        }

        public void Registrar(string login, string clave, string rol)
        {
            if (string.IsNullOrWhiteSpace(login) || login.Length > 30)
                throw new ArgumentException("El usuario es obligatorio y tiene como máximo 30 caracteres.");
            if (clave == null || clave.Length < 8)
                throw new ArgumentException("La contraseña debe tener al menos 8 caracteres.");
            if (Array.IndexOf(Roles, rol) < 0)
                throw new ArgumentException("Rol no válido.");
            if (dal.BuscarPorLogin(login) != null)
                throw new ArgumentException("Ese usuario ya existe.");

            string sal = Seguridad.NuevaSal();           // 1) genera una sal aleatoria
            string hash = Seguridad.Hash(clave, sal);    // 2) calcula el hash de la clave con esa sal
            dal.Insertar(new Usuario { Login = login, Sal = sal, ClaveHash = hash, Rol = rol });   // 3) guarda (NO la clave)
        }

        public bool HayUsuarios()
        {
            return dal.Contar() > 0;
        }

        // Búsqueda siempre con consulta parametrizada
        public List<Usuario> Buscar(string login)
        {
            return dal.Buscar(login);
        }
    }
}
