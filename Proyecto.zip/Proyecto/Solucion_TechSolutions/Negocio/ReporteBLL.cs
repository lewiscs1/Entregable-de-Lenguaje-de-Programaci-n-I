// CAPA NEGOCIO (BLL) – reportes. Limpia y valida los filtros; la pantalla no tiene SQL.
using System;
using System.Collections.Generic;
using Datos;
using Entidades;

namespace Negocio
{
    public class ReporteBLL
    {
        private readonly ReporteDAL dal = new ReporteDAL();

        public List<Cliente> ReporteClientes(string nombre)
        {
            return dal.ListarClientes(LimpiarNombre(nombre));
        }

        public List<Producto> ReporteProductos(string nombre)
        {
            return dal.ListarProductos(LimpiarNombre(nombre));
        }

        public List<ReporteVenta> ReporteVentas(DateTime desde, DateTime hasta)
        {
            if (desde.Date > hasta.Date)
                throw new ArgumentException("La fecha 'Desde' no puede ser mayor que la fecha 'Hasta'.");
            return dal.ListarVentas(desde, hasta);
        }

        // Texto vacío = todos. Máximo 100 caracteres (igual que VARCHAR(100) del procedimiento).
        private static string LimpiarNombre(string nombre)
        {
            string texto = (nombre ?? string.Empty).Trim();
            if (texto.Length > 100)
                throw new ArgumentException("El filtro admite como máximo 100 caracteres.");
            return texto;
        }
    }
}
