﻿// CAPA NEGOCIO (BLL) – clientes. Consultas con LINQ y expresiones lambda (sin foreach ni ordenamiento manual).
// Referencias: proyectos Entidades y Datos
using System;
using System.Collections.Generic;
using System.Linq;          // Where, OrderBy, FirstOrDefault, Count, All
using Datos;
using Entidades;

namespace Negocio
{
    public class ClienteBLL
    {
        private readonly ClienteDAL dal = new ClienteDAL();

        public void Registrar(Cliente p)
        {
            // Reglas de negocio: se validan aquí, no en el formulario ni en la BD.
            if (p == null)
                throw new ArgumentNullException("p");
            if (string.IsNullOrWhiteSpace(p.Dni) || p.Dni.Length != 8 || !p.Dni.All(char.IsDigit))
                throw new ArgumentException("El DNI debe tener 8 dígitos.");
            if (string.IsNullOrWhiteSpace(p.Nombres) || p.Nombres.Length > 100)
                throw new ArgumentException("Ingrese los nombres del cliente (máximo 100 caracteres).");
            if (!string.IsNullOrWhiteSpace(p.Telefono) && p.Telefono.Length > 15)
                throw new ArgumentException("El teléfono admite como máximo 15 caracteres.");

            dal.Insertar(p);
        }

        // Where + OrderBy: clientes cuyo nombre o DNI contiene el criterio, de la A a la Z.
        // Criterio vacío = todos los clientes.
        public List<Cliente> BuscarClientes(string criterio)
        {
            string texto = (criterio ?? string.Empty).Trim();

            return dal.Listar()
                      .Where(p => texto.Length == 0
                               || p.Nombres.IndexOf(texto, StringComparison.CurrentCultureIgnoreCase) >= 0
                               || p.Dni.Contains(texto))
                      .OrderBy(p => p.Nombres, StringComparer.CurrentCultureIgnoreCase)
                      .ToList();
        }

        // FirstOrDefault: el cliente con ese DNI, o null si no existe
        public Cliente BuscarPorDni(string dni)
        {
            string buscado = (dni ?? string.Empty).Trim();
            return dal.Listar().FirstOrDefault(p => p.Dni == buscado);
        }

        // Count con condición: cuántos clientes no tienen teléfono
        public int ObtenerTotalClientesSinTelefono()
        {
            return dal.Listar().Count(p => string.IsNullOrWhiteSpace(p.Telefono));
        }
    }
}
