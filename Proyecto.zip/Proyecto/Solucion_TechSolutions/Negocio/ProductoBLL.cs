﻿// CAPA NEGOCIO (BLL) – productos e inventario. Consultas con LINQ y expresiones lambda (sin foreach).
using System;
using System.Collections.Generic;
using System.Linq;          // Where, OrderBy, FirstOrDefault, Count
using Datos;
using Entidades;

namespace Negocio
{
    public class ProductoBLL
    {
        public const int StockBajo = 5;      // desde 5 unidades hacia abajo se considera stock bajo

        private readonly ProductoDAL dal = new ProductoDAL();

        // Todos los productos de la A a la Z (para listas desplegables).
        public List<Producto> Listar()
        {
            return dal.Listar().OrderBy(p => p.Nombre, StringComparer.CurrentCultureIgnoreCase).ToList();
        }

        // Where + OrderBy: productos cuyo nombre contiene el criterio. Criterio vacío = todos.
        public List<Producto> BuscarProductos(string criterio)
        {
            string texto = (criterio ?? string.Empty).Trim();

            return dal.Listar()
                      .Where(p => texto.Length == 0
                               || p.Nombre.IndexOf(texto, StringComparison.CurrentCultureIgnoreCase) >= 0)
                      .OrderBy(p => p.Nombre, StringComparer.CurrentCultureIgnoreCase)
                      .ToList();
        }

        // FirstOrDefault: el producto con ese id, o null si no existe
        public Producto BuscarPorId(int id)
        {
            return dal.Listar().FirstOrDefault(p => p.Id == id);
        }

        // Count con condición: cuántos productos tienen stock bajo
        public int ObtenerTotalStockBajo()
        {
            return dal.Listar().Count(p => p.Stock <= StockBajo);
        }

        public void Registrar(Producto p)
        {
            if (p == null)
                throw new ArgumentNullException("p");
            if (string.IsNullOrWhiteSpace(p.Nombre) || p.Nombre.Length > 100)
                throw new ArgumentException("Ingrese el nombre del producto (máximo 100 caracteres).");
            if (p.Stock < 0)
                throw new ArgumentException("El stock inicial no puede ser negativo.");
            if (p.PrecioUnitario <= 0)
                throw new ArgumentException("El precio debe ser mayor que cero.");

            dal.Insertar(p);
        }

        public void IngresarStock(int idProducto, int cantidad)
        {
            if (idProducto <= 0)
                throw new ArgumentException("Seleccione un producto.");
            if (cantidad <= 0)
                throw new ArgumentException("La cantidad a ingresar debe ser mayor que cero.");

            if (dal.IngresarStock(idProducto, cantidad) == 0)
                throw new ArgumentException("El producto ya no existe.");
        }
    }
}
