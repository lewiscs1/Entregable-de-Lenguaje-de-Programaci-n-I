﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace Negocio
{
    public static class Seguridad
    {
        public const int Iteraciones = 600000;      // factor de estiramiento (OWASP 2023 para PBKDF2-HMAC-SHA256)
        private const int TamanoSalBytes = 16;      // 128 bits
        private const int TamanoHashBytes = 32;     // 256 bits

        // Sal aleatoria criptográficamente segura, distinta para cada usuario.
        public static string NuevaSal()
        {
            byte[] sal = new byte[TamanoSalBytes];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(sal);
            }
            return Convert.ToBase64String(sal);
        }

        public static string Hash(string clave, string salBase64)
        {
            if (clave == null) throw new ArgumentNullException("clave");
            if (string.IsNullOrEmpty(salBase64)) throw new ArgumentException("La sal es obligatoria.", "salBase64");

            byte[] sal = Convert.FromBase64String(salBase64);
            using (Rfc2898DeriveBytes pbkdf2 = new Rfc2898DeriveBytes(clave, sal, Iteraciones, HashAlgorithmName.SHA256))
            {
                return Convert.ToBase64String(pbkdf2.GetBytes(TamanoHashBytes));
            }
        }

        // Al iniciar sesión se calcula el hash de lo que escribió el usuario con SU sal y se compara.
        public static bool Verificar(string clave, string salBase64, string hashGuardado)
        {
            if (clave == null || string.IsNullOrEmpty(salBase64) || string.IsNullOrEmpty(hashGuardado))
                return false;

            byte[] calculado = Convert.FromBase64String(Hash(clave, salBase64));
            byte[] guardado;
            try
            {
                guardado = Convert.FromBase64String(hashGuardado);
            }
            catch (FormatException)
            {
                return false;
            }
            return ComparacionTiempoConstante(calculado, guardado);
        }

        // Compara todos los bytes siempre (el tiempo no revela en qué posición hay diferencia).
        [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
        private static bool ComparacionTiempoConstante(byte[] a, byte[] b)
        {
            uint diferencia = (uint)a.Length ^ (uint)b.Length;
            for (int i = 0; i < a.Length && i < b.Length; i++)
            {
                diferencia |= (uint)(a[i] ^ b[i]);
            }
            return diferencia == 0;
        }
    }
}
