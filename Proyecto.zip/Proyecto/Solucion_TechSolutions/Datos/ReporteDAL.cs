// Proyecto: Datos (Capa DAL) – llama a los procedimientos almacenados de los reportes.
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class ReporteDAL
    {
        // dbo.usp_ReporteClientes (@Nombre VARCHAR(100)) -> Dni, Nombres, Telefono
        public List<Cliente> ListarClientes(string nombre)
        {
            var lista = new List<Cliente>();
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand("dbo.usp_ReporteClientes", cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Nombre", SqlDbType.VarChar, 100).Value = nombre;
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Cliente
                        {
                            Dni = dr["Dni"].ToString(),
                            Nombres = dr["Nombres"].ToString(),
                            Telefono = dr["Telefono"].ToString()
                        });
                    }
                }
            }
            return lista;
        }

        // dbo.usp_ReporteProductos (@Nombre VARCHAR(100)) -> Nombre, Stock, PrecioUnitario
        public List<Producto> ListarProductos(string nombre)
        {
            var lista = new List<Producto>();
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand("dbo.usp_ReporteProductos", cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Nombre", SqlDbType.VarChar, 100).Value = nombre;
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Producto
                        {
                            Nombre = dr["Nombre"].ToString(),
                            Stock = Convert.ToInt32(dr["Stock"]),
                            PrecioUnitario = Convert.ToDecimal(dr["PrecioUnitario"])
                        });
                    }
                }
            }
            return lista;
        }

        // dbo.usp_ReporteVentas (@Desde DATE, @Hasta DATE) -> IdVenta, Fecha, Cliente, Vendedor, Total
        public List<ReporteVenta> ListarVentas(DateTime desde, DateTime hasta)
        {
            var lista = new List<ReporteVenta>();
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand("dbo.usp_ReporteVentas", cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Desde", SqlDbType.Date).Value = desde.Date;
                cmd.Parameters.Add("@Hasta", SqlDbType.Date).Value = hasta.Date;
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new ReporteVenta
                        {
                            IdVenta = Convert.ToInt32(dr["IdVenta"]),
                            Fecha = Convert.ToDateTime(dr["Fecha"]),
                            Cliente = dr["Cliente"].ToString(),
                            Vendedor = dr["Vendedor"].ToString(),
                            Total = Convert.ToDecimal(dr["Total"])
                        });
                    }
                }
            }
            return lista;
        }
    }
}
