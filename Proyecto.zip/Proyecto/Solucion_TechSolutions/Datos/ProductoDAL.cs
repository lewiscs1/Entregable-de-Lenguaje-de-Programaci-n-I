﻿// Proyecto: Datos (Biblioteca de clases) - Capa DAL
// Consultas parametrizadas con tipo y tamaño de cada columna (sin AddWithValue, sin concatenar SQL).
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class ProductoDAL
    {
        // LINQ vive en Negocio: Datos solo trae TODOS los productos a una lista (sin filtrar).
        public List<Producto> Listar()
        {
            var lista = new List<Producto>();
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT IdProducto, Nombre, Stock, PrecioUnitario FROM Producto", cn))
            {
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Producto
                        {
                            Id = dr.GetInt32(0),
                            Nombre = dr.GetString(1),
                            Stock = dr.GetInt32(2),
                            PrecioUnitario = dr.GetDecimal(3)
                        });
                    }
                }
            }
            return lista;
        }

        public int Insertar(Producto p)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "INSERT INTO Producto (Nombre, Stock, PrecioUnitario) VALUES (@nom, @stock, @precio)", cn))
            {
                cmd.Parameters.Add("@nom", SqlDbType.VarChar, 100).Value = p.Nombre;
                cmd.Parameters.Add("@stock", SqlDbType.Int).Value = p.Stock;
                SqlParameter precio = cmd.Parameters.Add("@precio", SqlDbType.Decimal);
                precio.Precision = 10;
                precio.Scale = 2;
                precio.Value = p.PrecioUnitario;
                cn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        // Ingreso de mercadería al almacén: suma unidades al stock actual (una sola sentencia atómica).
        public int IngresarStock(int idProducto, int cantidad)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "UPDATE Producto SET Stock = Stock + @cant WHERE IdProducto = @id", cn))
            {
                cmd.Parameters.Add("@cant", SqlDbType.Int).Value = cantidad;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = idProducto;
                cn.Open();
                return cmd.ExecuteNonQuery();
            }
        }
    }
}
