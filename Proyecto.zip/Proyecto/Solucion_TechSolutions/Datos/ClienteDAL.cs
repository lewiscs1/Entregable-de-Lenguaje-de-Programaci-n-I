﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class ClienteDAL
    {
        public int Insertar(Cliente p)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "INSERT INTO Cliente (Dni, Nombres, Telefono) VALUES (@dni, @nom, @tel)", cn))
            {
                // Mismo tipo y tamaño que las columnas: CHAR(8), VARCHAR(100), VARCHAR(15) NULL
                cmd.Parameters.Add("@dni", SqlDbType.Char, 8).Value = p.Dni;
                cmd.Parameters.Add("@nom", SqlDbType.VarChar, 100).Value = p.Nombres;
                cmd.Parameters.Add("@tel", SqlDbType.VarChar, 15).Value =
                    string.IsNullOrWhiteSpace(p.Telefono) ? (object)DBNull.Value : p.Telefono;
                cn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        // LINQ vive en Negocio: Datos solo trae TODOS los clientes a una lista (sin filtrar).
        public List<Cliente> Listar()
        {
            var lista = new List<Cliente>();
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT IdCliente, Dni, Nombres, Telefono FROM Cliente", cn))
            {
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new Cliente
                        {
                            Id = dr.GetInt32(0),
                            Dni = dr.GetString(1),
                            Nombres = dr.GetString(2),
                            Telefono = dr.IsDBNull(3) ? string.Empty : dr.GetString(3)
                        });
                    }
                }
            }
            return lista;
        }
    }
}
