﻿using System.Configuration;
using System.Data.SqlClient;

namespace Datos
{
    public sealed class Conexion
    {
        private const string NombreCadena = "TechSolutions";

        private static Conexion instancia;                              // la única instancia
        private static readonly object candado = new object();          // exclusión mutua (lock)
        private readonly string cadena;

        // Constructor estrictamente privado
        private Conexion()
        {
            ConnectionStringSettings config = ConfigurationManager.ConnectionStrings[NombreCadena];
            if (config == null || string.IsNullOrWhiteSpace(config.ConnectionString))
            {
                throw new ConfigurationErrorsException(
                    "No se encontró la cadena de conexión '" + NombreCadena + "' en el archivo App.config.");
            }
            cadena = config.ConnectionString;
        }

        // Punto de acceso global: un solo hilo a la vez puede crear la instancia
        public static Conexion Instancia
        {
            get
            {
                lock (candado)
                {
                    if (instancia == null)
                    {
                        instancia = new Conexion();
                    }
                    return instancia;
                }
            }
        }

        // Cada operación crea y cierra SU PROPIA conexión (ADO.NET usa el "pool" de conexiones).
        // El Singleton comparte la configuración, no una conexión abierta.
        public SqlConnection Crear()
        {
            return new SqlConnection(cadena);
        }
    }
}
