﻿// CAPA DATOS (DAL) – tabla Usuario.
// TODAS las consultas son PARAMETRIZADAS con cmd.Parameters.Add("@p", SqlDbType, tamaño):
// el texto que escribe el usuario viaja como DATO, nunca como parte del SQL (evita la inyección SQL).
// No existe ninguna consulta construida por concatenación de texto del usuario.
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class UsuarioDAL
    {
        private const string ColumnasUsuario =
            "IdUsuario, Login, ClaveHash, Sal, Rol, IntentosFallidos, Bloqueado";

        // Busca al usuario que intenta iniciar sesión (null si no existe).
        public Usuario BuscarPorLogin(string login)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT " + ColumnasUsuario + " FROM Usuario WHERE Login = @login", cn))
            {
                // @login con el MISMO tipo y tamaño que la columna: VARCHAR(30)
                cmd.Parameters.Add("@login", SqlDbType.VarChar, 30).Value = login;
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    return dr.Read() ? Leer(dr) : null;
                }
            }
        }

        // Fija el contador de intentos y el estado de bloqueo de una cuenta
        // (por ejemplo: (login, 0, false) al iniciar sesión bien; soporte técnico también puede desbloquear).
        public void ActualizarIntentosYBloqueo(string login, int intentos, bool bloqueado)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "UPDATE Usuario SET IntentosFallidos = @intentos, Bloqueado = @bloqueado WHERE Login = @login", cn))
            {
                cmd.Parameters.Add("@intentos", SqlDbType.Int).Value = intentos;
                cmd.Parameters.Add("@bloqueado", SqlDbType.Bit).Value = bloqueado;
                cmd.Parameters.Add("@login", SqlDbType.VarChar, 30).Value = login;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Suma UN intento fallido de forma ATÓMICA (una sola sentencia UPDATE en el servidor):
        // si dos intentos llegan a la vez, SQL Server los serializa y ninguno se pierde.
        // Al llegar a maxIntentos, la misma sentencia bloquea la cuenta.
        // Devuelve true si la cuenta quedó bloqueada; "intentos" trae el contador resultante.
        public bool RegistrarIntentoFallido(string login, int maxIntentos, out int intentos)
        {
            intentos = 0;
            bool bloqueado = false;

            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "UPDATE Usuario SET IntentosFallidos = IntentosFallidos + 1, " +
                "Bloqueado = CASE WHEN IntentosFallidos + 1 >= @max THEN 1 ELSE Bloqueado END " +
                "OUTPUT inserted.IntentosFallidos, inserted.Bloqueado " +
                "WHERE Login = @login AND Bloqueado = 0", cn))
            {
                cmd.Parameters.Add("@max", SqlDbType.Int).Value = maxIntentos;
                cmd.Parameters.Add("@login", SqlDbType.VarChar, 30).Value = login;
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        intentos = dr.GetInt32(0);
                        bloqueado = dr.GetBoolean(1);
                    }
                }
            }
            return bloqueado;
        }

        public void Insertar(Usuario u)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "INSERT INTO Usuario (Login, ClaveHash, Sal, Rol) VALUES (@login, @hash, @sal, @rol)", cn))
            {
                cmd.Parameters.Add("@login", SqlDbType.VarChar, 30).Value = u.Login;
                cmd.Parameters.Add("@hash", SqlDbType.VarChar, 100).Value = u.ClaveHash;
                cmd.Parameters.Add("@sal", SqlDbType.VarChar, 50).Value = u.Sal;
                cmd.Parameters.Add("@rol", SqlDbType.VarChar, 20).Value = u.Rol;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public int Contar()
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Usuario", cn))
            {
                cn.Open();
                return (int)cmd.ExecuteScalar();
            }
        }

        // Búsqueda de usuarios (consulta parametrizada: un texto como  ' OR 1=1 --  no devuelve filas).
        public List<Usuario> Buscar(string login)
        {
            var lista = new List<Usuario>();
            using (SqlConnection cn = Conexion.Instancia.Crear())
            using (SqlCommand cmd = new SqlCommand(
                "SELECT " + ColumnasUsuario + " FROM Usuario WHERE Login = @login", cn))
            {
                cmd.Parameters.Add("@login", SqlDbType.VarChar, 30).Value = login ?? string.Empty;
                cn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(Leer(dr));
                    }
                }
            }
            return lista;
        }

        // Columna (tipo SQL) -> propiedad (tipo C#):  INT -> int · VARCHAR -> string · BIT -> bool
        private static Usuario Leer(SqlDataReader dr)
        {
            return new Usuario
            {
                Id = dr.GetInt32(0),
                Login = dr.GetString(1),
                ClaveHash = dr.GetString(2),
                Sal = dr.GetString(3),
                Rol = dr.GetString(4),
                IntentosFallidos = dr.GetInt32(5),
                Bloqueado = dr.GetBoolean(6)
            };
        }
    }
}
