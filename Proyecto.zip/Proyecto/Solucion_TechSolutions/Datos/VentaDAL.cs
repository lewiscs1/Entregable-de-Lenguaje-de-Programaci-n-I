﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class VentaDAL
    {
        // Devuelve el número de la venta. Si falla cualquier línea, se revierte TODO (venta y stock).
        public int Registrar(int idUsuario, int idCliente, IList<LineaVenta> lineas)
        {
            using (SqlConnection cn = Conexion.Instancia.Crear())
            {
                cn.Open();
                using (SqlTransaction tx = cn.BeginTransaction())          // 1) inicia la transacción
                {
                    try
                    {
                        // 2) cabecera de la venta (el total se completa al final)
                        int idVenta;
                        using (SqlCommand cmd = new SqlCommand(
                            "INSERT INTO Venta (IdUsuario, IdCliente, Total) VALUES (@usu, @cli, 0); " +
                            "SELECT CAST(SCOPE_IDENTITY() AS INT);", cn, tx))   // el comando se vincula a la transacción
                        {
                            cmd.Parameters.Add("@usu", SqlDbType.Int).Value = idUsuario;
                            cmd.Parameters.Add("@cli", SqlDbType.Int).Value = idCliente;
                            idVenta = (int)cmd.ExecuteScalar();
                        }

                        decimal total = 0;
                        foreach (LineaVenta l in lineas)
                        {
                            // 3) descuenta el stock SOLO si alcanza y devuelve el precio vigente de la base
                            object precioDb;
                            using (SqlCommand cmd = new SqlCommand(
                                "UPDATE Producto SET Stock = Stock - @cant " +
                                "OUTPUT inserted.PrecioUnitario " +
                                "WHERE IdProducto = @prod AND Stock >= @cant", cn, tx))
                            {
                                cmd.Parameters.Add("@cant", SqlDbType.Int).Value = l.Cantidad;
                                cmd.Parameters.Add("@prod", SqlDbType.Int).Value = l.IdProducto;
                                precioDb = cmd.ExecuteScalar();               // null = no alcanzó el stock o no existe
                            }
                            if (precioDb == null)
                                throw new InvalidOperationException(
                                    "Stock insuficiente o producto inexistente: " + l.Producto + ". La venta no se registró.");

                            decimal precio = (decimal)precioDb;
                            decimal subtotal = precio * l.Cantidad;
                            total += subtotal;

                            using (SqlCommand cmd = new SqlCommand(
                                "INSERT INTO DetalleVenta (IdVenta, IdProducto, Cantidad, PrecioUnitario, Subtotal) " +
                                "VALUES (@venta, @prod, @cant, @precio, @sub)", cn, tx))
                            {
                                cmd.Parameters.Add("@venta", SqlDbType.Int).Value = idVenta;
                                cmd.Parameters.Add("@prod", SqlDbType.Int).Value = l.IdProducto;
                                cmd.Parameters.Add("@cant", SqlDbType.Int).Value = l.Cantidad;
                                SqlParameter p1 = cmd.Parameters.Add("@precio", SqlDbType.Decimal);
                                p1.Precision = 10; p1.Scale = 2; p1.Value = precio;
                                SqlParameter p2 = cmd.Parameters.Add("@sub", SqlDbType.Decimal);
                                p2.Precision = 12; p2.Scale = 2; p2.Value = subtotal;
                                cmd.ExecuteNonQuery();
                            }
                        }

                        using (SqlCommand cmd = new SqlCommand(
                            "UPDATE Venta SET Total = @total WHERE IdVenta = @venta", cn, tx))
                        {
                            SqlParameter pt = cmd.Parameters.Add("@total", SqlDbType.Decimal);
                            pt.Precision = 12; pt.Scale = 2; pt.Value = total;
                            cmd.Parameters.Add("@venta", SqlDbType.Int).Value = idVenta;
                            cmd.ExecuteNonQuery();
                        }

                        tx.Commit();                                          // 4) todo salió bien: se confirma
                        return idVenta;
                    }
                    catch
                    {
                        try { tx.Rollback(); }                                // 5) algo falló: se revierte TODO
                        catch (InvalidOperationException) { }                 // la transacción ya no estaba activa
                        throw;
                    }
                }
            }
        }
    }
}
