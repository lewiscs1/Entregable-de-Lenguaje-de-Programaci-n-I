﻿// Proyecto: Entidades
// Una línea del detalle de la venta: qué producto, cuántas unidades y a qué precio.
namespace Entidades
{
    public class LineaVenta
    {
        public int IdProducto { get; set; }
        public string Producto { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnitario { get; set; }

        public decimal Subtotal
        {
            get { return Cantidad * PrecioUnitario; }
        }
    }
}
