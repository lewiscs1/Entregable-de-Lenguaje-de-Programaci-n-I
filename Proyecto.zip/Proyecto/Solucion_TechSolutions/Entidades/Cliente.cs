﻿// Proyecto: Entidades (Biblioteca de clases)
namespace Entidades
{
    public class Cliente
    {
        public int Id { get; set; }
        public string Dni { get; set; }
        public string Nombres { get; set; }
        public string Telefono { get; set; }
    }
}
