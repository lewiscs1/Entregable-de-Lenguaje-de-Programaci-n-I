// Proyecto: Entidades
// Una fila del reporte de ventas (lo que devuelve usp_ReporteVentas).
using System;

namespace Entidades
{
    public class ReporteVenta
    {
        public int IdVenta { get; set; }
        public DateTime Fecha { get; set; }
        public string Cliente { get; set; }
        public string Vendedor { get; set; }
        public decimal Total { get; set; }
    }
}
