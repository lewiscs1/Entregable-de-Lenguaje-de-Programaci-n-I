﻿// Proyecto: Entidades
namespace Entidades
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int Stock { get; set; }
        public decimal PrecioUnitario { get; set; }

        // Texto que se muestra en las listas desplegables (no es una columna de la base)
        public string Texto
        {
            get { return Nombre + "  ·  S/ " + PrecioUnitario.ToString("0.00") + "  ·  stock " + Stock; }
        }
    }
}
