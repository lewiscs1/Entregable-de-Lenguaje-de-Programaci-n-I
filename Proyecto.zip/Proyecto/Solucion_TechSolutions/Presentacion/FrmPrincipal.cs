﻿// CAPA PRESENTACIÓN – menú principal.
//  1) SEGURIDAD BASADA EN ROLES (RBAC) con mínimo privilegio: todo se oculta y solo se habilita lo que el rol necesita.
//  2) CIERRE DE SESIÓN POR INACTIVIDAD con el control Timer: 10 s sin mover el mouse ni usar el teclado -> vuelve el login.
using System;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public partial class FrmPrincipal : Form
    {
        // ===== INACTIVIDAD (1/4): datos que usa el Timer =====
        private const int LimiteInactividadSegundos = 10;   // segundos permitidos sin actividad
        private const int IntervaloTimerMs = 1000;          // el evento Tick ocurre cada 1000 ms = 1 s
        private int segundosInactivo;                       // cuántos segundos lleva sin actividad

        private Usuario usuarioActual;                      // "token" de la sesión; se destruye al cerrar

        // Permisos calculados según el rol (por defecto TODO denegado)
        private bool puedeGestionarClientes;
        private bool puedeConsultarClientes;
        private bool puedeGestionarProductos;
        private bool puedeVender;
        private bool puedeGestionarUsuarios;
        private bool puedeVerReportes;                      // SEMANA 11

        public bool CerradaPorInactividad { get; private set; }   // FrmLogin la consulta al cerrar

        public FrmPrincipal(Usuario u)
        {
            if (u == null) throw new ArgumentNullException("u");
            InitializeComponent();
            if (Program.Icono != null) Icon = Program.Icono;
            usuarioActual = u;
        }

        // ===== INACTIVIDAD (2/4) + RBAC: al cargar el formulario =====
        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            lblBienvenida.Text = "Bienvenido, " + usuarioActual.Login + " (" + usuarioActual.Rol + ")";
            AplicarPermisosPorRol();

            // KeyPreview = true (también en el Designer): el formulario recibe las teclas antes que sus controles.
            KeyPreview = true;
            segundosInactivo = 0;
            tmrInactividad.Interval = IntervaloTimerMs;
            tmrInactividad.Start();           // enciende el Timer (equivale a Enabled = true)
        }

        // Principio de mínimo privilegio: se parte de "nada permitido" y cada rol suma solo lo suyo.
        //                       Administrador   Vendedor   Almacenero
        // Clientes                   sí            sí          no
        // Consultar clientes         sí            sí          no
        // Productos (inventario)     sí            no          sí
        // Ventas                     sí            sí          no
        // Usuarios                   sí            no          no
        // Reportes                   sí            sí          sí   (cada rol ve solo sus reportes en FrmReportes)
        // Un rol desconocido no ve ningún menú.
        private void AplicarPermisosPorRol()
        {
            puedeGestionarClientes = false;
            puedeConsultarClientes = false;
            puedeGestionarProductos = false;
            puedeVender = false;
            puedeGestionarUsuarios = false;
            puedeVerReportes = false;

            switch (usuarioActual.Rol)
            {
                case UsuarioBLL.RolAdministrador:
                    puedeGestionarClientes = true;
                    puedeConsultarClientes = true;
                    puedeGestionarProductos = true;
                    puedeVender = true;
                    puedeGestionarUsuarios = true;
                    puedeVerReportes = true;
                    break;
                case UsuarioBLL.RolVendedor:
                    puedeGestionarClientes = true;
                    puedeConsultarClientes = true;
                    puedeVender = true;
                    puedeVerReportes = true;
                    break;
                case UsuarioBLL.RolAlmacenero:
                    puedeGestionarProductos = true;
                    puedeVerReportes = true;
                    break;
            }

            mnuClientes.Visible = puedeGestionarClientes;
            mnuConsultaClientes.Visible = puedeConsultarClientes;
            mnuProductos.Visible = puedeGestionarProductos;
            mnuVentas.Visible = puedeVender;
            mnuUsuarios.Visible = puedeGestionarUsuarios;
            mnuReportes.Visible = puedeVerReportes;
        }

        // ===== INACTIVIDAD (3/4): cada segundo suma 1; al llegar a 10 cierra la sesión =====
        private void tmrInactividad_Tick(object sender, EventArgs e)
        {
            segundosInactivo++;
            if (segundosInactivo < LimiteInactividadSegundos) return;

            tmrInactividad.Stop();            // detiene el Timer ANTES del mensaje (equivale a Enabled = false)
            CerradaPorInactividad = true;
            usuarioActual = null;             // se destruye la sesión activa
            MessageBox.Show(this, "La sesión se cerró por inactividad.", "Tech Solutions",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
            Close();                          // FrmLogin vuelve a aparecer
        }

        // ===== INACTIVIDAD (4/4): mover el mouse o pulsar una tecla reinicia la cuenta =====
        // Este método está enlazado a MouseMove (formulario, menú y etiqueta) y a KeyDown del formulario.
        private void Actividad(object sender, EventArgs e)
        {
            segundosInactivo = 0;
        }

        // Cuando se detiene el formulario, el Timer se apaga de forma limpia.
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            tmrInactividad.Stop();
            base.OnFormClosed(e);
        }

        // Mientras se trabaja en otra ventana (por ejemplo, Clientes), el Timer se detiene
        private void Abrir(Form ventana)
        {
            tmrInactividad.Stop();
            using (ventana)
            {
                ventana.ShowDialog(this);
            }
            segundosInactivo = 0;
            if (!IsDisposed) tmrInactividad.Start();
        }

        // Defensa en profundidad: además de ocultar el menú, cada opción revalida el permiso.
        private void mnuClientes_Click(object sender, EventArgs e)
        {
            if (!puedeGestionarClientes) { Denegar(); return; }
            Abrir(new FrmCliente());
        }

        private void mnuConsultaClientes_Click(object sender, EventArgs e)
        {
            if (!puedeConsultarClientes) { Denegar(); return; }
            Abrir(new FrmConsultaClientes());
        }

        private void mnuProductos_Click(object sender, EventArgs e)
        {
            if (!puedeGestionarProductos) { Denegar(); return; }
            Abrir(new FrmProductos());
        }

        private void mnuVentas_Click(object sender, EventArgs e)
        {
            if (!puedeVender) { Denegar(); return; }
            Abrir(new FrmVenta(usuarioActual));
        }

        private void mnuUsuarios_Click(object sender, EventArgs e)
        {
            if (!puedeGestionarUsuarios) { Denegar(); return; }
            Abrir(new FrmUsuarios(false));
        }

        private void mnuReportes_Click(object sender, EventArgs e)
        {
            if (!puedeVerReportes) { Denegar(); return; }
            Abrir(new FrmReportes(usuarioActual));
        }

        private void Denegar()
        {
            MessageBox.Show("No tiene permiso para esta opción.", "Acceso denegado",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
