﻿// CAPA PRESENTACIÓN – registrar una venta (Vendedor y Administrador).
// La venta se guarda con una TRANSACCIÓN (Negocio\VentaBLL -> Datos\VentaDAL): o se confirma completa (COMMIT)
// o se revierte por completo (ROLLBACK) si algún producto no tiene stock suficiente.
using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public class FrmVenta : Form
    {
        private readonly Usuario vendedor;
        private readonly ClienteBLL clienteBll = new ClienteBLL();
        private readonly ProductoBLL productoBll = new ProductoBLL();
        private readonly VentaBLL ventaBll = new VentaBLL();
        private readonly BindingList<LineaVenta> lineas = new BindingList<LineaVenta>();

        private ComboBox cboCliente;
        private ComboBox cboProducto;
        private NumericUpDown nudCantidad;
        private Button btnAgregar;
        private Button btnQuitar;
        private DataGridView dgvDetalle;
        private Label lblTotal;
        private Button btnRegistrar;

        public FrmVenta(Usuario u)
        {
            if (u == null) throw new ArgumentNullException("u");
            vendedor = u;
            ConstruirPantalla();
            Load += FrmVenta_Load;
        }

        private void ConstruirPantalla()
        {
            Text = "Registrar venta";
            ClientSize = new Size(640, 430);
            StartPosition = FormStartPosition.CenterParent;

            Label l1 = new Label { Text = "Cliente:", Location = new Point(15, 18), AutoSize = true };
            cboCliente = new ComboBox { Location = new Point(85, 15), Width = 330, DropDownStyle = ComboBoxStyle.DropDownList };

            Label l2 = new Label { Text = "Producto:", Location = new Point(15, 52), AutoSize = true };
            cboProducto = new ComboBox { Location = new Point(85, 49), Width = 330, DropDownStyle = ComboBoxStyle.DropDownList };
            Label l3 = new Label { Text = "Cantidad:", Location = new Point(430, 52), AutoSize = true };
            nudCantidad = new NumericUpDown { Location = new Point(495, 49), Width = 60, Minimum = 1, Maximum = 10000, Value = 1 };
            btnAgregar = new Button { Text = "Agregar", Location = new Point(85, 80), Width = 90 };
            btnAgregar.Click += btnAgregar_Click;
            btnQuitar = new Button { Text = "Quitar línea", Location = new Point(185, 80), Width = 100 };
            btnQuitar.Click += btnQuitar_Click;

            dgvDetalle = new DataGridView
            {
                Location = new Point(15, 115),
                Size = new Size(610, 220),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvDetalle.DataSource = lineas;
            if (dgvDetalle.Columns["IdProducto"] != null) dgvDetalle.Columns["IdProducto"].Visible = false;

            lblTotal = new Label { Text = "Total: S/ 0.00", Location = new Point(15, 348), AutoSize = true, Font = new Font(Font, FontStyle.Bold) };
            btnRegistrar = new Button { Text = "Registrar venta", Location = new Point(495, 385), Width = 130, Height = 30 };
            btnRegistrar.Click += btnRegistrar_Click;

            Controls.AddRange(new Control[] { l1, cboCliente, l2, cboProducto, l3, nudCantidad, btnAgregar, btnQuitar, dgvDetalle, lblTotal, btnRegistrar });
        }

        private void FrmVenta_Load(object sender, EventArgs e)
        {
            try
            {
                // Los clientes salen de ClienteBLL (LINQ: Where vacío + OrderBy de la A a la Z)
                cboCliente.DisplayMember = "Nombres";
                cboCliente.ValueMember = "Id";
                cboCliente.DataSource = clienteBll.BuscarClientes("");
                CargarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudieron cargar los datos: " + ex.Message, "Error");
            }
        }

        private void CargarProductos()
        {
            cboProducto.DataSource = null;
            cboProducto.DisplayMember = "Texto";
            cboProducto.ValueMember = "Id";
            cboProducto.DataSource = productoBll.Listar();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Producto p = cboProducto.SelectedItem as Producto;
            if (p == null)
            {
                MessageBox.Show("Seleccione un producto.", "Validación");
                return;
            }
            int cantidad = (int)nudCantidad.Value;

            // FirstOrDefault: ¿ya está este producto en el detalle?
            LineaVenta existente = lineas.FirstOrDefault(l => l.IdProducto == p.Id);
            int yaEnLista = existente == null ? 0 : existente.Cantidad;
            if (yaEnLista + cantidad > p.Stock)
            {
                MessageBox.Show("Stock insuficiente de " + p.Nombre + ". Disponible: " + p.Stock + ".", "Validación");
                return;
            }

            if (existente == null)
                lineas.Add(new LineaVenta { IdProducto = p.Id, Producto = p.Nombre, Cantidad = cantidad, PrecioUnitario = p.PrecioUnitario });
            else
                existente.Cantidad += cantidad;

            lineas.ResetBindings();
            ActualizarTotal();
        }

        private void btnQuitar_Click(object sender, EventArgs e)
        {
            LineaVenta l = dgvDetalle.CurrentRow == null ? null : dgvDetalle.CurrentRow.DataBoundItem as LineaVenta;
            if (l == null) return;
            lineas.Remove(l);
            ActualizarTotal();
        }

        private void ActualizarTotal()
        {
            lblTotal.Text = "Total: S/ " + ventaBll.CalcularTotal(lineas).ToString("0.00");   // Sum
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            Cliente c = cboCliente.SelectedItem as Cliente;
            try
            {
                int idVenta = ventaBll.Registrar(vendedor.Id, c == null ? 0 : c.Id, lineas.ToList());   // COMMIT o ROLLBACK
                MessageBox.Show("Venta N.º " + idVenta + " registrada. " + lblTotal.Text + "\nEl stock se descontó.", "Venta confirmada (COMMIT)");
                lineas.Clear();
                ActualizarTotal();
                CargarProductos();                 // muestra el stock actualizado
            }
            catch (ArgumentException ex)           // regla de negocio no cumplida
            {
                MessageBox.Show(ex.Message, "Validación");
            }
            catch (Exception ex)                   // por ejemplo, stock insuficiente: se revirtió todo (ROLLBACK)
            {
                MessageBox.Show(ex.Message + "\n\nNo se guardó nada (ROLLBACK).", "Venta revertida");
                CargarProductos();
            }
        }
    }
}
