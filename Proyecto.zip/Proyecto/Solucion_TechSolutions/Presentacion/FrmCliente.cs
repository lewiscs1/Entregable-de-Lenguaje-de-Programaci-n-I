﻿// Proyecto: Presentacion (Aplicación Windows Forms) – proyecto de inicio
// Referencias: proyectos Entidades y Negocio (NO referencia a Datos)
using System;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public partial class FrmCliente : Form
    {
        private readonly ClienteBLL bll = new ClienteBLL();

        public FrmCliente()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                var p = new Cliente { Dni = txtDni.Text.Trim(), Nombres = txtNombres.Text.Trim(), Telefono = txtTelefono.Text.Trim() };
                bll.Registrar(p);
                MessageBox.Show("Cliente registrado.");
            }
            catch (ArgumentException ex)          // regla de negocio no cumplida
            {
                MessageBox.Show(ex.Message, "Validación");
            }
            catch (Exception ex)                  // por ejemplo, DNI repetido (UNIQUE) o sin conexión
            {
                MessageBox.Show("No se pudo registrar: " + ex.Message, "Error");
            }
        }
    }
}
