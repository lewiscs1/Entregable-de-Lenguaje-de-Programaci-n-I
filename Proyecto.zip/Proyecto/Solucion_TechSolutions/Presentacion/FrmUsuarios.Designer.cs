﻿namespace Presentacion
{
    partial class FrmUsuarios
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblRegistrar = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.lblClave = new System.Windows.Forms.Label();
            this.txtClave = new System.Windows.Forms.TextBox();
            this.lblRol = new System.Windows.Forms.Label();
            this.cboRol = new System.Windows.Forms.ComboBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.lblBuscarTitulo = new System.Windows.Forms.Label();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.dgvUsuarios = new System.Windows.Forms.DataGridView();
            this.lblFilas = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // lblRegistrar
            this.lblRegistrar.Name = "lblRegistrar";
            this.lblRegistrar.Text = "Registrar usuario";
            this.lblRegistrar.Location = new System.Drawing.Point(20, 12);
            this.lblRegistrar.AutoSize = true;
            this.lblRegistrar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            // lblLogin
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Text = "Usuario:";
            this.lblLogin.Location = new System.Drawing.Point(20, 45);
            this.lblLogin.AutoSize = true;
            // txtLogin
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Location = new System.Drawing.Point(120, 42);
            this.txtLogin.Size = new System.Drawing.Size(200, 23);
            this.txtLogin.MaxLength = 30;
            // lblClave
            this.lblClave.Name = "lblClave";
            this.lblClave.Text = "Contraseña:";
            this.lblClave.Location = new System.Drawing.Point(20, 80);
            this.lblClave.AutoSize = true;
            // txtClave
            this.txtClave.Name = "txtClave";
            this.txtClave.Location = new System.Drawing.Point(120, 77);
            this.txtClave.Size = new System.Drawing.Size(200, 23);
            this.txtClave.UseSystemPasswordChar = true;
            // lblRol
            this.lblRol.Name = "lblRol";
            this.lblRol.Text = "Rol:";
            this.lblRol.Location = new System.Drawing.Point(20, 115);
            this.lblRol.AutoSize = true;
            // cboRol
            this.cboRol.Name = "cboRol";
            this.cboRol.Location = new System.Drawing.Point(120, 112);
            this.cboRol.Size = new System.Drawing.Size(200, 23);
            this.cboRol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // btnRegistrar
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.Location = new System.Drawing.Point(340, 75);
            this.btnRegistrar.Size = new System.Drawing.Size(130, 32);
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // lblBuscarTitulo
            this.lblBuscarTitulo.Name = "lblBuscarTitulo";
            this.lblBuscarTitulo.Text = "Buscar usuario (consulta parametrizada)";
            this.lblBuscarTitulo.Location = new System.Drawing.Point(20, 158);
            this.lblBuscarTitulo.AutoSize = true;
            this.lblBuscarTitulo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            // txtBuscar
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Location = new System.Drawing.Point(20, 188);
            this.txtBuscar.Size = new System.Drawing.Size(250, 23);
            // btnBuscar
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.Location = new System.Drawing.Point(280, 185);
            this.btnBuscar.Size = new System.Drawing.Size(90, 30);
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // dgvUsuarios
            this.dgvUsuarios.Name = "dgvUsuarios";
            this.dgvUsuarios.Location = new System.Drawing.Point(20, 225);
            this.dgvUsuarios.Size = new System.Drawing.Size(640, 215);
            this.dgvUsuarios.ReadOnly = true;
            this.dgvUsuarios.AllowUserToAddRows = false;
            this.dgvUsuarios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            // lblFilas
            this.lblFilas.Name = "lblFilas";
            this.lblFilas.Text = "Filas devueltas: 0";
            this.lblFilas.Location = new System.Drawing.Point(20, 450);
            this.lblFilas.AutoSize = true;
            this.Controls.Add(this.lblRegistrar);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.lblClave);
            this.Controls.Add(this.txtClave);
            this.Controls.Add(this.lblRol);
            this.Controls.Add(this.cboRol);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.lblBuscarTitulo);
            this.Controls.Add(this.txtBuscar);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.dgvUsuarios);
            this.Controls.Add(this.lblFilas);
            this.ClientSize = new System.Drawing.Size(680, 480);
            this.Name = "FrmUsuarios";
            this.Text = "Usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmUsuarios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblRegistrar;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Label lblClave;
        private System.Windows.Forms.TextBox txtClave;
        private System.Windows.Forms.Label lblRol;
        private System.Windows.Forms.ComboBox cboRol;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Label lblBuscarTitulo;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.DataGridView dgvUsuarios;
        private System.Windows.Forms.Label lblFilas;
    }
}
