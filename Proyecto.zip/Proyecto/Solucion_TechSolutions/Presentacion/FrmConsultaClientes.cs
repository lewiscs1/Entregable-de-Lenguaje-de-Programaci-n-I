﻿// CAPA PRESENTACIÓN – SEMANA 10 · LINQ: consultar clientes
// La pantalla solo pide y muestra: las consultas LINQ están en Negocio\ClienteBLL.cs
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public partial class FrmConsultaClientes : Form
    {
        private readonly ClienteBLL bll = new ClienteBLL();

        public FrmConsultaClientes()
        {
            InitializeComponent();
        }

        private void FrmConsultaClientes_Load(object sender, EventArgs e)
        {
            Mostrar(bll.BuscarClientes(""));                       // texto vacío = todos, de la A a la Z
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            Mostrar(bll.BuscarClientes(txtNombre.Text.Trim()));    // Where + OrderBy
        }

        private void btnBuscarDni_Click(object sender, EventArgs e)
        {
            Cliente p = bll.BuscarPorDni(txtDni.Text.Trim());   // FirstOrDefault
            if (p == null)
            {
                MessageBox.Show("No existe un cliente con ese DNI.", "Consultar clientes");
                return;
            }
            Mostrar(new List<Cliente> { p });
        }

        private void Mostrar(List<Cliente> lista)
        {
            dgvClientes.DataSource = lista;
            lblTotal.Text = "Mostrando " + lista.Count + " cliente(s) · Sin teléfono: " + bll.ObtenerTotalClientesSinTelefono();   // Count
        }
    }
}
