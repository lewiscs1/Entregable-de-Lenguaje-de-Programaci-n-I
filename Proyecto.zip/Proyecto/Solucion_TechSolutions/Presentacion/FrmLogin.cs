﻿// CAPA PRESENTACIÓN – inicio de sesión
using System;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public partial class FrmLogin : Form
    {
        private readonly UsuarioBLL bll = new UsuarioBLL();

        public FrmLogin()
        {
            InitializeComponent();
            if (Program.Icono != null) Icon = Program.Icono;
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario u = bll.Autenticar(txtLogin.Text.Trim(), txtClave.Text);
                FrmPrincipal principal = new FrmPrincipal(u);
                principal.FormClosed += Principal_FormClosed;   // SEMANA 10: saber cómo se cerró
                principal.Show();
                Hide();
            }
            catch (UnauthorizedAccessException ex)
            {
                MessageBox.Show(ex.Message, "Acceso denegado");   // mensaje genérico
                txtClave.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo conectar: " + ex.Message, "Error");
            }
        }

        // SEMANA 10: si el menú se cerró por inactividad, vuelve el login; si no, termina la aplicación
        private void Principal_FormClosed(object sender, FormClosedEventArgs e)
        {
            FrmPrincipal principal = (FrmPrincipal)sender;
            if (principal.CerradaPorInactividad)
            {
                txtClave.Clear();
                Show();
            }
            else
            {
                Application.Exit();
            }
        }
    }
}
