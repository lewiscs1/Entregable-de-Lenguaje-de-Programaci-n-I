﻿namespace Presentacion
{
    partial class FrmCliente
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblDni = new System.Windows.Forms.Label();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.lblNombres = new System.Windows.Forms.Label();
            this.txtNombres = new System.Windows.Forms.TextBox();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // lblDni
            this.lblDni.Name = "lblDni";
            this.lblDni.Text = "DNI:";
            this.lblDni.Location = new System.Drawing.Point(20, 23);
            this.lblDni.AutoSize = true;
            // txtDni
            this.txtDni.Name = "txtDni";
            this.txtDni.Location = new System.Drawing.Point(110, 20);
            this.txtDni.Size = new System.Drawing.Size(210, 23);
            this.txtDni.MaxLength = 8;
            // lblNombres
            this.lblNombres.Name = "lblNombres";
            this.lblNombres.Text = "Nombres:";
            this.lblNombres.Location = new System.Drawing.Point(20, 58);
            this.lblNombres.AutoSize = true;
            // txtNombres
            this.txtNombres.Name = "txtNombres";
            this.txtNombres.Location = new System.Drawing.Point(110, 55);
            this.txtNombres.Size = new System.Drawing.Size(210, 23);
            // lblTelefono
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Text = "Teléfono:";
            this.lblTelefono.Location = new System.Drawing.Point(20, 93);
            this.lblTelefono.AutoSize = true;
            // txtTelefono
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Location = new System.Drawing.Point(110, 90);
            this.txtTelefono.Size = new System.Drawing.Size(210, 23);
            // btnGuardar
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.Location = new System.Drawing.Point(110, 130);
            this.btnGuardar.Size = new System.Drawing.Size(120, 32);
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            this.Controls.Add(this.lblDni);
            this.Controls.Add(this.txtDni);
            this.Controls.Add(this.lblNombres);
            this.Controls.Add(this.txtNombres);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.btnGuardar);
            this.ClientSize = new System.Drawing.Size(360, 200);
            this.Name = "FrmCliente";
            this.Text = "Registrar cliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblDni;
        private System.Windows.Forms.TextBox txtDni;
        private System.Windows.Forms.Label lblNombres;
        private System.Windows.Forms.TextBox txtNombres;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Button btnGuardar;
    }
}
