﻿namespace Presentacion
{
    partial class FrmConsultaClientes
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.lblDni = new System.Windows.Forms.Label();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.btnBuscarDni = new System.Windows.Forms.Button();
            this.dgvClientes = new System.Windows.Forms.DataGridView();
            this.lblTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).BeginInit();
            this.SuspendLayout();
            this.lblNombre.Name = "lblNombre"; this.lblNombre.Text = "Nombre:"; this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(20, 23);
            this.txtNombre.Name = "txtNombre"; this.txtNombre.Location = new System.Drawing.Point(90, 20);
            this.txtNombre.Size = new System.Drawing.Size(200, 23);
            this.btnBuscar.Name = "btnBuscar"; this.btnBuscar.Text = "Buscar";
            this.btnBuscar.Location = new System.Drawing.Point(300, 19); this.btnBuscar.Size = new System.Drawing.Size(80, 26);
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            this.lblDni.Name = "lblDni"; this.lblDni.Text = "DNI:"; this.lblDni.AutoSize = true;
            this.lblDni.Location = new System.Drawing.Point(20, 58);
            this.txtDni.Name = "txtDni"; this.txtDni.Location = new System.Drawing.Point(90, 55);
            this.txtDni.Size = new System.Drawing.Size(200, 23); this.txtDni.MaxLength = 8;
            this.btnBuscarDni.Name = "btnBuscarDni"; this.btnBuscarDni.Text = "Buscar";
            this.btnBuscarDni.Location = new System.Drawing.Point(300, 54); this.btnBuscarDni.Size = new System.Drawing.Size(80, 26);
            this.btnBuscarDni.Click += new System.EventHandler(this.btnBuscarDni_Click);
            this.dgvClientes.Name = "dgvClientes";
            this.dgvClientes.Location = new System.Drawing.Point(20, 95);
            this.dgvClientes.Size = new System.Drawing.Size(540, 220);
            this.dgvClientes.ReadOnly = true;
            this.dgvClientes.AllowUserToAddRows = false;
            this.dgvClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.lblTotal.Name = "lblTotal"; this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(20, 325);
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Controls.Add(this.lblNombre); this.Controls.Add(this.txtNombre); this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.lblDni); this.Controls.Add(this.txtDni); this.Controls.Add(this.btnBuscarDni);
            this.Controls.Add(this.dgvClientes); this.Controls.Add(this.lblTotal);
            this.ClientSize = new System.Drawing.Size(580, 355);
            this.Name = "FrmConsultaClientes";
            this.Text = "Consultar clientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmConsultaClientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label lblDni;
        private System.Windows.Forms.TextBox txtDni;
        private System.Windows.Forms.Button btnBuscarDni;
        private System.Windows.Forms.DataGridView dgvClientes;
        private System.Windows.Forms.Label lblTotal;
    }
}
