﻿// CAPA PRESENTACIÓN – usuarios: registrar (hash con sal) y buscar (consulta parametrizada)
using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class FrmUsuarios : Form
    {
        private readonly UsuarioBLL bll = new UsuarioBLL();
        private readonly bool primerAdministrador;

        // primerAdministrador = true: aún no hay usuarios; se crea el Administrador y se cierra.
        public FrmUsuarios(bool primerAdministrador)
        {
            InitializeComponent();
            this.primerAdministrador = primerAdministrador;
        }

        private void FrmUsuarios_Load(object sender, EventArgs e)
        {
            cboRol.Items.AddRange(UsuarioBLL.Roles);
            cboRol.SelectedIndex = 0;
            if (primerAdministrador)
            {
                Text = "Configuración inicial: primer administrador";
                cboRol.Enabled = false;          // el primer usuario siempre es Administrador
                txtBuscar.Enabled = false; btnBuscar.Enabled = false;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                bll.Registrar(txtLogin.Text.Trim(), txtClave.Text, cboRol.Text);
                MessageBox.Show("Usuario registrado. Se guardaron la sal y el hash, no la contraseña.");
                txtLogin.Clear(); txtClave.Clear();
                if (primerAdministrador) Close();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Validación");
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo registrar: " + ex.Message, "Error");
            }
        }

        // Escribe un usuario (o  ' OR 1=1 --): la consulta parametrizada no devuelve filas.
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                dgvUsuarios.DataSource = bll.Buscar(txtBuscar.Text.Trim());
                lblFilas.Text = "Filas devueltas: " + dgvUsuarios.Rows.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en la consulta: " + ex.Message, "Error");
            }
        }
    }
}
