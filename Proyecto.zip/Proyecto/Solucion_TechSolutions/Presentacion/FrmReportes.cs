// CAPA PRESENTACIÓN – SEMANA 11 · Reportes e impresión
// Datos (procedimiento almacenado) + Diseño (.rdlc) + Parámetro -> Visor (ReportViewer: muestra, imprime, exporta a PDF)
// La pantalla no tiene SQL: pide los datos a Negocio\ReporteBLL.cs.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Entidades;
using Microsoft.Reporting.WinForms;
using Negocio;

namespace Presentacion
{
    public class FrmReportes : Form
    {
        private const string RepClientes = "Clientes";
        private const string RepProductos = "Productos (inventario)";
        private const string RepVentas = "Ventas por fechas";

        private readonly Usuario usuario;
        private readonly ReporteBLL bll = new ReporteBLL();

        private Panel pnlFiltros;
        private Label lblReporte;
        private ComboBox cboReporte;
        private Label lblFiltro;
        private TextBox txtFiltro;
        private Label lblDesde;
        private DateTimePicker dtpDesde;
        private Label lblHasta;
        private DateTimePicker dtpHasta;
        private Button btnVer;
        private ReportViewer visor;

        public FrmReportes(Usuario u)
        {
            if (u == null) throw new ArgumentNullException("u");
            usuario = u;
            ConstruirPantalla();
            Load += FrmReportes_Load;
        }

        private void ConstruirPantalla()
        {
            Text = "Reportes";
            ClientSize = new Size(900, 650);
            StartPosition = FormStartPosition.CenterScreen;
            if (Program.Icono != null) Icon = Program.Icono;

            visor = new ReportViewer();
            visor.Dock = DockStyle.Fill;

            pnlFiltros = new Panel();
            pnlFiltros.Dock = DockStyle.Top;
            pnlFiltros.Height = 50;

            lblReporte = new Label { Text = "Reporte:", AutoSize = true, Location = new Point(12, 17) };
            cboReporte = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(70, 13),
                Size = new Size(190, 23)
            };
            cboReporte.SelectedIndexChanged += cboReporte_SelectedIndexChanged;

            lblFiltro = new Label { Text = "Nombre:", AutoSize = true, Location = new Point(280, 17) };
            txtFiltro = new TextBox { Location = new Point(340, 13), Size = new Size(200, 23), MaxLength = 100 };

            lblDesde = new Label { Text = "Desde:", AutoSize = true, Location = new Point(280, 17) };
            dtpDesde = new DateTimePicker
            {
                Format = DateTimePickerFormat.Short,
                Location = new Point(330, 13),
                Size = new Size(110, 23),
                Value = DateTime.Today.AddMonths(-1)
            };
            lblHasta = new Label { Text = "Hasta:", AutoSize = true, Location = new Point(455, 17) };
            dtpHasta = new DateTimePicker
            {
                Format = DateTimePickerFormat.Short,
                Location = new Point(505, 13),
                Size = new Size(110, 23),
                Value = DateTime.Today
            };

            btnVer = new Button { Text = "Ver reporte", Location = new Point(640, 11), Size = new Size(110, 28) };
            btnVer.Click += btnVer_Click;

            pnlFiltros.Controls.AddRange(new Control[]
            {
                lblReporte, cboReporte, lblFiltro, txtFiltro, lblDesde, dtpDesde, lblHasta, dtpHasta, btnVer
            });

            // Primero el control que llena (Fill) y después el que se ancla arriba (Top).
            Controls.Add(visor);
            Controls.Add(pnlFiltros);
            AcceptButton = btnVer;
        }

        // Principio de mínimo privilegio: cada rol solo ve los reportes que necesita.
        //                       Administrador   Vendedor   Almacenero
        // Clientes                   sí            sí          no
        // Productos                  sí            no          sí
        // Ventas por fechas          sí            sí          no
        private void FrmReportes_Load(object sender, EventArgs e)
        {
            var permitidos = new List<string>();
            switch (usuario.Rol)
            {
                case UsuarioBLL.RolAdministrador:
                    permitidos.Add(RepClientes);
                    permitidos.Add(RepProductos);
                    permitidos.Add(RepVentas);
                    break;
                case UsuarioBLL.RolVendedor:
                    permitidos.Add(RepClientes);
                    permitidos.Add(RepVentas);
                    break;
                case UsuarioBLL.RolAlmacenero:
                    permitidos.Add(RepProductos);
                    break;
            }

            cboReporte.DataSource = permitidos;
            btnVer.Enabled = permitidos.Count > 0;
            AjustarFiltros();
        }

        private void cboReporte_SelectedIndexChanged(object sender, EventArgs e)
        {
            AjustarFiltros();
        }

        // Clientes y productos filtran por nombre; ventas filtra por rango de fechas.
        private void AjustarFiltros()
        {
            string reporte = cboReporte.SelectedItem as string;
            bool porFechas = reporte == RepVentas;

            lblFiltro.Visible = !porFechas;
            txtFiltro.Visible = !porFechas;
            lblDesde.Visible = porFechas;
            dtpDesde.Visible = porFechas;
            lblHasta.Visible = porFechas;
            dtpHasta.Visible = porFechas;
            lblFiltro.Text = reporte == RepProductos ? "Producto:" : "Nombre:";
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            try
            {
                string reporte = cboReporte.SelectedItem as string;
                if (reporte == null) return;

                visor.Reset();                                   // limpia el reporte anterior
                LocalReport informe = visor.LocalReport;
                informe.DataSources.Clear();

                switch (reporte)
                {
                    case RepClientes:
                    {
                        string filtro = txtFiltro.Text.Trim();
                        List<Cliente> datos = bll.ReporteClientes(filtro);                  // DATOS
                        informe.ReportEmbeddedResource = "Presentacion.ReporteClientes.rdlc";   // DISEÑO
                        informe.DataSources.Add(new ReportDataSource("DataSet1", datos));
                        informe.SetParameters(new[]
                        {
                            new ReportParameter("Filtro", filtro.Length == 0 ? "Todos" : filtro)
                        });
                        break;
                    }
                    case RepProductos:
                    {
                        string filtro = txtFiltro.Text.Trim();
                        List<Producto> datos = bll.ReporteProductos(filtro);
                        informe.ReportEmbeddedResource = "Presentacion.ReporteProductos.rdlc";
                        informe.DataSources.Add(new ReportDataSource("DataSet1", datos));
                        informe.SetParameters(new[]
                        {
                            new ReportParameter("Filtro", filtro.Length == 0 ? "Todos" : filtro)
                        });
                        break;
                    }
                    case RepVentas:
                    {
                        List<ReporteVenta> datos = bll.ReporteVentas(dtpDesde.Value, dtpHasta.Value);
                        informe.ReportEmbeddedResource = "Presentacion.ReporteVentas.rdlc";
                        informe.DataSources.Add(new ReportDataSource("DataSet1", datos));
                        informe.SetParameters(new[]
                        {
                            new ReportParameter("Desde", dtpDesde.Value.ToString("dd/MM/yyyy")),
                            new ReportParameter("Hasta", dtpHasta.Value.ToString("dd/MM/yyyy"))
                        });
                        break;
                    }
                }

                visor.SetDisplayMode(DisplayMode.PrintLayout);   // vista de impresión
                visor.RefreshReport();                           // MOSTRAR
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Reportes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo mostrar el reporte. Revise la conexión con SQL Server.\n\n" + ex.Message,
                                "Reportes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
