﻿// CAPA PRESENTACIÓN – inventario (Almacenero y Administrador): consultar, ingresar stock y registrar productos.
// La pantalla solo pide y muestra: las consultas LINQ están en Negocio\ProductoBLL.cs
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public class FrmProductos : Form
    {
        private readonly ProductoBLL bll = new ProductoBLL();

        private TextBox txtBuscar;
        private Button btnBuscar;
        private DataGridView dgvProductos;
        private Label lblTotal;
        private NumericUpDown nudIngreso;
        private Button btnIngresar;
        private TextBox txtNombre;
        private NumericUpDown nudStockInicial;
        private TextBox txtPrecio;
        private Button btnNuevo;

        public FrmProductos()
        {
            ConstruirPantalla();
            Load += FrmProductos_Load;
        }

        private void ConstruirPantalla()
        {
            Text = "Inventario de productos";
            ClientSize = new Size(640, 470);
            StartPosition = FormStartPosition.CenterParent;

            Label l1 = new Label { Text = "Producto:", Location = new Point(15, 18), AutoSize = true };
            txtBuscar = new TextBox { Location = new Point(85, 15), Width = 200 };
            btnBuscar = new Button { Text = "Buscar", Location = new Point(295, 13), Width = 80 };
            btnBuscar.Click += btnBuscar_Click;

            dgvProductos = new DataGridView
            {
                Location = new Point(15, 50),
                Size = new Size(610, 220),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            lblTotal = new Label { Location = new Point(15, 277), AutoSize = true };

            GroupBox gbIngreso = new GroupBox { Text = "Ingreso de mercadería (producto seleccionado)", Location = new Point(15, 305), Size = new Size(610, 55) };
            Label l2 = new Label { Text = "Cantidad:", Location = new Point(12, 24), AutoSize = true };
            nudIngreso = new NumericUpDown { Location = new Point(80, 21), Width = 80, Minimum = 1, Maximum = 100000, Value = 1 };
            btnIngresar = new Button { Text = "Ingresar stock", Location = new Point(175, 19), Width = 110 };
            btnIngresar.Click += btnIngresar_Click;
            gbIngreso.Controls.AddRange(new Control[] { l2, nudIngreso, btnIngresar });

            GroupBox gbNuevo = new GroupBox { Text = "Registrar producto nuevo", Location = new Point(15, 368), Size = new Size(610, 90) };
            Label l3 = new Label { Text = "Nombre:", Location = new Point(12, 26), AutoSize = true };
            txtNombre = new TextBox { Location = new Point(70, 23), Width = 220, MaxLength = 100 };
            Label l4 = new Label { Text = "Stock inicial:", Location = new Point(305, 26), AutoSize = true };
            nudStockInicial = new NumericUpDown { Location = new Point(385, 23), Width = 70, Minimum = 0, Maximum = 100000, Value = 0 };
            Label l5 = new Label { Text = "Precio S/:", Location = new Point(470, 26), AutoSize = true };
            txtPrecio = new TextBox { Location = new Point(530, 23), Width = 65 };
            btnNuevo = new Button { Text = "Registrar producto", Location = new Point(70, 53), Width = 130 };
            btnNuevo.Click += btnNuevo_Click;
            gbNuevo.Controls.AddRange(new Control[] { l3, txtNombre, l4, nudStockInicial, l5, txtPrecio, btnNuevo });

            Controls.AddRange(new Control[] { l1, txtBuscar, btnBuscar, dgvProductos, lblTotal, gbIngreso, gbNuevo });
            AcceptButton = btnBuscar;
        }

        private void FrmProductos_Load(object sender, EventArgs e)
        {
            Mostrar(bll.BuscarProductos(""));                     // texto vacío = todos, de la A a la Z
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            Mostrar(bll.BuscarProductos(txtBuscar.Text.Trim()));  // Where + OrderBy
        }

        private void Mostrar(List<Producto> lista)
        {
            dgvProductos.DataSource = lista;
            if (dgvProductos.Columns["Texto"] != null) dgvProductos.Columns["Texto"].Visible = false;
            if (dgvProductos.Columns["Id"] != null) dgvProductos.Columns["Id"].Visible = false;
            lblTotal.Text = "Mostrando " + lista.Count + " producto(s) · Con stock bajo (" + ProductoBLL.StockBajo + " o menos): "
                            + bll.ObtenerTotalStockBajo();         // Count
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            Producto p = dgvProductos.CurrentRow == null ? null : dgvProductos.CurrentRow.DataBoundItem as Producto;
            if (p == null)
            {
                MessageBox.Show("Seleccione un producto de la lista.", "Inventario");
                return;
            }
            try
            {
                bll.IngresarStock(p.Id, (int)nudIngreso.Value);
                MessageBox.Show("Se ingresaron " + (int)nudIngreso.Value + " unidad(es) de " + p.Nombre + ".", "Inventario");
                Mostrar(bll.BuscarProductos(txtBuscar.Text.Trim()));
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Validación");
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo ingresar el stock: " + ex.Message, "Error");
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            decimal precio;
            if (!decimal.TryParse(txtPrecio.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out precio))
            {
                MessageBox.Show("Escriba un precio válido, por ejemplo 45.50", "Validación");
                return;
            }
            try
            {
                bll.Registrar(new Producto { Nombre = txtNombre.Text.Trim(), Stock = (int)nudStockInicial.Value, PrecioUnitario = precio });
                MessageBox.Show("Producto registrado.", "Inventario");
                txtNombre.Clear(); txtPrecio.Clear(); nudStockInicial.Value = 0;
                Mostrar(bll.BuscarProductos(txtBuscar.Text.Trim()));
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Validación");
            }
            catch (Exception ex)                  // por ejemplo, nombre repetido (UNIQUE) o sin conexión
            {
                MessageBox.Show("No se pudo registrar: " + ex.Message, "Error");
            }
        }
    }
}
