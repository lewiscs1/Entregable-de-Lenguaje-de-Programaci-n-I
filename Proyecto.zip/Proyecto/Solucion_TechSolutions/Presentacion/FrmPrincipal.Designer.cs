﻿namespace Presentacion
{
    partial class FrmPrincipal
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrInactividad = new System.Windows.Forms.Timer(this.components);   // SEMANA 10: control Timer
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lblBienvenida = new System.Windows.Forms.Label();
            this.mnuClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuConsultaClientes = new System.Windows.Forms.ToolStripMenuItem();   // SEMANA 10 · LINQ
            this.mnuProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuVentas = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUsuarios = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReportes = new System.Windows.Forms.ToolStripMenuItem();   // SEMANA 11: reportes
            this.SuspendLayout();
            // menuStrip1
            this.menuStrip1.Name = "menuStrip1";
            // lblBienvenida
            this.lblBienvenida.Name = "lblBienvenida";
            this.lblBienvenida.Text = "Bienvenido";
            this.lblBienvenida.Location = new System.Drawing.Point(20, 60);
            this.lblBienvenida.AutoSize = true;
            this.mnuClientes.Name = "mnuClientes";
            this.mnuClientes.Text = "Clientes";
            this.mnuClientes.Click += new System.EventHandler(this.mnuClientes_Click);
            this.mnuConsultaClientes.Name = "mnuConsultaClientes";
            this.mnuConsultaClientes.Text = "Consultar clientes";
            this.mnuConsultaClientes.Click += new System.EventHandler(this.mnuConsultaClientes_Click);
            this.mnuProductos.Name = "mnuProductos";
            this.mnuProductos.Text = "Productos";
            this.mnuProductos.Click += new System.EventHandler(this.mnuProductos_Click);
            this.mnuVentas.Name = "mnuVentas";
            this.mnuVentas.Text = "Ventas";
            this.mnuVentas.Click += new System.EventHandler(this.mnuVentas_Click);
            this.mnuUsuarios.Name = "mnuUsuarios";
            this.mnuUsuarios.Text = "Usuarios";
            this.mnuUsuarios.Click += new System.EventHandler(this.mnuUsuarios_Click);
            this.mnuReportes.Name = "mnuReportes";
            this.mnuReportes.Text = "Reportes";
            this.mnuReportes.Click += new System.EventHandler(this.mnuReportes_Click);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuClientes, this.mnuConsultaClientes, this.mnuProductos, this.mnuVentas, this.mnuReportes, this.mnuUsuarios });
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.lblBienvenida);
            this.ClientSize = new System.Drawing.Size(520, 240);
            this.Name = "FrmPrincipal";
            this.Text = "Tech Solutions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.MainMenuStrip = this.menuStrip1;
            // SEMANA 10: Timer de inactividad y eventos que cuentan como actividad
            this.tmrInactividad.Interval = 1000;
            this.tmrInactividad.Tick += new System.EventHandler(this.tmrInactividad_Tick);
            this.KeyPreview = true;
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Actividad);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Actividad);
            this.menuStrip1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Actividad);
            this.lblBienvenida.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Actividad);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label lblBienvenida;
        private System.Windows.Forms.ToolStripMenuItem mnuClientes;
        private System.Windows.Forms.ToolStripMenuItem mnuConsultaClientes;
        private System.Windows.Forms.ToolStripMenuItem mnuProductos;
        private System.Windows.Forms.ToolStripMenuItem mnuVentas;
        private System.Windows.Forms.ToolStripMenuItem mnuUsuarios;
        private System.Windows.Forms.ToolStripMenuItem mnuReportes;
        private System.Windows.Forms.Timer tmrInactividad;
    }
}
