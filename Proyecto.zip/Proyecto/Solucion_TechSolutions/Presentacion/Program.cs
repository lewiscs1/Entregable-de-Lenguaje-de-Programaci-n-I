﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    internal static class Program
    {
        // Ícono único de la aplicación (el mismo del .exe: techsolutions.ico) para todas las ventanas.
        private static Icon icono;
        internal static Icon Icono
        {
            get
            {
                if (icono == null)
                {
                    try { icono = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
                    catch (Exception) { icono = null; }
                }
                return icono;
            }
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Si todavía no hay usuarios, primero se crea el Administrador.
            var bll = new UsuarioBLL();
            if (!bll.HayUsuarios())
            {
                Application.Run(new FrmUsuarios(true));
                if (!bll.HayUsuarios()) return;   // cerró sin registrar
            }
            Application.Run(new FrmLogin());
        }
    }
}
